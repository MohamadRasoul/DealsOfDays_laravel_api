<?php

namespace App;

use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements JWTSubject
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'userName', 'gender', 'dateOfBirth', 'email', 'password',
    ];
    
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];



    public function companies()
    {
        return $this->hasMany('App\Company');
    }

    public function reviews()
    {
        return $this->hasMany('App\Review');
    }

    public function searshHistories()
    {
        return $this->hasMany('App\SearshHistory');
    }

    public function offersCopons()
    {
        return $this->belongsToMany('App\Offer', 'copons', 'user_id', 'offer_id')->withPivot('copon', 'active');
    }

    public function offersFavorite()
    {
        return $this->belongsToMany('App\Offer', 'favorites', 'user_id', 'offer_id');
    }

    public function branchsFollow()
    {
        return $this->belongsToMany('App\Branch', 'follows', 'user_id', 'branch_id');
    }


    // Rest omitted for brevity

    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
}
