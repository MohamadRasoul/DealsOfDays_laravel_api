<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BranchOffer extends Model
{
    protected $guarded = [];

}
