<?php

namespace App\Http\Controllers\API;


use App\BranchOffer;
use Illuminate\Http\Request;

class BranchOfferController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\BranchOffer  $branchOffer
     * @return \Illuminate\Http\Response
     */
    public function show(BranchOffer $branchOffer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\BranchOffer  $branchOffer
     * @return \Illuminate\Http\Response
     */
    public function edit(BranchOffer $branchOffer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\BranchOffer  $branchOffer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, BranchOffer $branchOffer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\BranchOffer  $branchOffer
     * @return \Illuminate\Http\Response
     */
    public function destroy(BranchOffer $branchOffer)
    {
        //
    }
}
